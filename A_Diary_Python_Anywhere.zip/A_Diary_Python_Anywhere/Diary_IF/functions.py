from .models import *
from django.contrib.auth.models import User

# user ownership
def user_ownership(user):
	# trash notes
	note_copy_objects = user.trashmodel_set.all().order_by('-id')
	note_copy_count = user.trashmodel_set.all().count()
	
	# notes
	note_count = user.notebookmodel_set.all().count()
	note_objects = user.notebookmodel_set.all().order_by('-id')

	# community post
	community_posts_counts = user.community_set.all().count()

	ownership_dict = {
		"note_objects": note_objects,
		"note_copy_objects": note_copy_objects,
		"note_count": note_count,
		"note_copy_count": note_copy_count,
		"community_posts_counts": community_posts_counts,
	}

	return ownership_dict

# login check 
def check_user(form_data):
	cd = form_data.cleaned_data
	username = cd['username']
	user = UserSignupForm.objects.filter(username = username)
	if user.count() == 1:
		c_user = UserSignupForm.objects.get(username = username)
		if cd['password'] == c_user.password1:
			return "logined"
		else:
			return 'w_pw'
	elif user.count() == 0 :
		return "user_does_not_exist"
	return None
# login check ##

# signup 
def check_user_name(form_data):
	cd = form_data.cleaned_data
	username = cd['username']
	user_name = UserSignupForm.objects.filter(username = username)
	if user_name.count():
		return None
	return username

def check_user_email(form_data):
	cd = form_data.cleaned_data
	email = cd['email']
	user_email = UserSignupForm.objects.filter(email = email)
	if user_email.count():
		return None
	return email

def check_user_pass(form_data):
	cd = form_data.cleaned_data
	password1 = cd['password1']
	password2 = cd['password2']

	if password1 and password2 and password1 != password2:
		# if len(password1) <= 8:
		return None
	return password1
# signup ##

# format date
def formatdate(date):
    return date.strftime("%b %d %Y %I:%M %p".format(date))

# cut long title
def cut_title(title):
	return title[0:15]

# ellipse title
def ellipse_title(objs):
	for i in objs:
		# ellipse title
		if len(i.note_title) > 15 :
			i.note_title = cut_title(i.note_title) + " ..."	
