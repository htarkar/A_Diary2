from django.apps import AppConfig


class DiaryIfConfig(AppConfig):
    name = 'Diary_IF'
