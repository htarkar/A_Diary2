from django.db import models
from .functions import user_directory_path
from .signup_model import UserSignupForm
# trash model
class TrashModel(models.Model):
	user = models.ForeignKey(UserSignupForm, name = 'user', on_delete= models.CASCADE, default = None, blank = True, null = True)
	note_author = models.CharField(max_length = 30, blank = False, null = True)
	note_title = models.CharField(max_length = 50, blank = False, null = True)
	note_body = models.CharField(max_length = 5000, blank = False, null = True)
	bg_color = models.CharField(max_length = 70, blank = True)
	text_color = models.CharField(max_length = 70, blank = True)
	note_image = models.ImageField(upload_to = user_directory_path, blank = True, null = True)
	deleted_date = models.DateTimeField(auto_now_add = True)
	
	def __str__(self):
		return self.note_author
