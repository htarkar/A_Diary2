from django.db import models

class Community_users(models.Model):
	username = models.CharField(max_length = 30, null = False, blank = False) 	
	communtiy_users = models.Manager()

	def __str__(self):
		return self.username