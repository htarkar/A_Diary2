from django.db import models
from .signup_model import UserSignupForm
from .functions import user_directory_path_community

class Community(models.Model):
	user = models.ForeignKey(UserSignupForm, name = 'user', on_delete= models.CASCADE, default = None, blank = True, null = True)
	author = models.CharField(max_length = 30, default = 'Unknown', blank = False)
	title = models.CharField(max_length = 50, default = 'Untitled Note', blank = True)
	body = models.CharField(max_length = 5000, blank = False, null = False)
	image = models.ImageField(upload_to = user_directory_path_community, blank = True)
	bg_color = models.CharField(max_length = 60, blank = True)
	text_color = models.CharField(max_length = 60, blank = True)
	posted_date = models.DateTimeField(auto_now_add = True)
	community_posts = models.Manager()

	def __str__(self):
		return self.title + ' by ' + str(self.user.username)