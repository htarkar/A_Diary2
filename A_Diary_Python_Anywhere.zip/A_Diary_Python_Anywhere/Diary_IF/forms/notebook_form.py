from ..models import NoteBookModel
from django import forms

# notebook form
class NoteBookModelForm(forms.ModelForm):
	class Meta:
		model = NoteBookModel
		fields = ['note_author', 'note_title', 'note_body', 'note_image']
		widgets = {
			'note_author': forms.HiddenInput(),
			'note_body': forms.Textarea(attrs = {
					'placeholder': 'Note here',
				}),
			'note_title': forms.TextInput(attrs = {
					'placeholder': 'Note title',
					'id': 'hide_bg'
				})
		}
