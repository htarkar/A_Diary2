from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from ..models import UserSignupForm

# signup form(custom)
class SignupForm(forms.ModelForm):
	class Meta:
		model = UserSignupForm
		fields = ['profile_image', "username", 'email', 'password1', 'password2']

		labels = {
			'username': 'Username',
			'password1': 'Password',
			'password2': 'Password Confirmation',
			'email': 'Email'
		}	

		widgets = {
			'username': forms.TextInput(attrs = {'id': 'signup_username'}),
			'password1': forms.PasswordInput(attrs = {'minlength': 8}),
			'password2': forms.PasswordInput(),
			'email': forms.EmailInput()
		}


# signup form
# class SignupForm(UserCreationForm):
# 	profile_image = forms.ImageField(required = False)
# 	email = forms.EmailField(max_length = 50, required = True)
# 	class Meta:
# 		model = User
# 		fields = ['profile_image', "username", 'email', 'password1', 'password2']

# 		labels = {
# 			'username': 'Username',
# 			'password1': 'Password',
# 			'password2': 'Password Confirmation',
# 			'email': 'Email'
# 		}	

# 		widgets = {
# 			'username': forms.TextInput(attrs = {'id': 'signup_username'}),
# 			'password1': forms.PasswordInput(attrs = {'minlength': 8}),
# 			'password2': forms.PasswordInput(),
# 			'email': forms.EmailInput()
# 		}
